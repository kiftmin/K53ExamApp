import { storage } from "./storage.js";
import { api } from "../shared/routes.js";
import { questionSchema, sourceSchema, MOBILE_NUMBER_REGEX, studySignSchema, rawSignImportSchema, type InsertStudySign, studyRuleSchema, rawRuleImportSchema, type InsertStudyRule } from "../shared/schema.js";
import {
  generateAccessCode,
  generateDailyCode,
  generateOnDemandCode,
  getExpiryForType,
  getTimeUntilNextCode,
  getTodaySAST,
  getTypeFromCode,
  requiresMobile,
  validateDailyCode,
  isValidMobile,
  type AccessCodeType,
} from "./access-code.js";
import { getAdminEmail, isSmtpConfigured, sendAdminEmail } from "./mailer.js";
import { slugifyCode, listStagedImages, stageImageUpload, attachStagedToCode, saveImageForCode, deleteStagedImage } from "./sign-images.js";
import { z } from "zod";

export async function registerRoutes(
  _httpServer: any,
  app: any
): Promise<any> {

  app.get(api.questions.list.path, async (req: any, res: any) => {
    try {
      const questions = await storage.getQuestions();
      res.json(questions);
    } catch (err) {
      console.error("Error reading questions:", err);
      res.status(500).json({ message: "Failed to load questions" });
    }
  });

  // === Bulk Question Endpoints ===

  app.post('/api/questions/bulk', async (req: any, res: any) => {
    try {
      const parsed = z.array(questionSchema).parse(req.body);
      await storage.bulkUploadQuestions(parsed);
      res.status(201).json({ message: `Successfully uploaded ${parsed.length} questions.` });
    } catch (err) {
      console.error("Error in bulk upload:", err);
      res.status(400).json({ message: "Invalid format for bulk upload payload", error: err });
    }
  });

  app.post('/api/questions/bulk-source', async (req: any, res: any) => {
    try {
      const { ids, sourceId } = z.object({
        ids: z.array(z.number()),
        sourceId: z.number().nullable()
      }).parse(req.body);

      await storage.bulkUpdateSource(ids, sourceId);
      res.json({ message: `Successfully updated ${ids.length} questions.` });
    } catch (err) {
      console.error("Error in bulk source update:", err);
      res.status(400).json({ message: "Invalid bulk source update payload", error: err });
    }
  });

  app.delete('/api/questions/bulk', async (req: any, res: any) => {
    try {
      const { ids } = z.object({
        ids: z.array(z.number())
      }).parse(req.body);

      await storage.bulkDeleteQuestions(ids);
      res.status(204).send();
    } catch (err) {
      console.error("Error in bulk delete:", err);
      res.status(400).json({ message: "Invalid bulk delete payload", error: err });
    }
  });

  app.post('/api/questions/bulk-official', async (req: any, res: any) => {
    try {
      const { ids, isOfficial } = z.object({
        ids: z.array(z.number()),
        isOfficial: z.boolean()
      }).parse(req.body);

      await storage.bulkUpdateOfficial(ids, isOfficial);
      res.json({ message: `Successfully updated ${ids.length} questions.` });
    } catch (err) {
      console.error("Error in bulk official update:", err);
      res.status(400).json({ message: "Invalid bulk official update payload", error: err });
    }
  });

  app.post('/api/questions/bulk-category', async (req: any, res: any) => {
    try {
      const { ids, category } = z.object({
        ids: z.array(z.number()),
        category: z.number()
      }).parse(req.body);

      await storage.bulkUpdateCategory(ids, category);
      res.json({ message: `Successfully updated ${ids.length} questions.` });
    } catch (err) {
      console.error("Error in bulk category update:", err);
      res.status(400).json({ message: "Invalid bulk category update payload", error: err });
    }
  });

  app.post('/api/questions/bulk-duplicate', async (req: any, res: any) => {
    try {
      const { ids, isDuplicate } = z.object({
        ids: z.array(z.number()),
        isDuplicate: z.boolean()
      }).parse(req.body);

      await storage.bulkUpdateDuplicate(ids, isDuplicate);
      res.json({ message: `Successfully updated ${ids.length} questions.` });
    } catch (err) {
      console.error("Error in bulk duplicate update:", err);
      res.status(400).json({ message: "Invalid bulk duplicate update payload", error: err });
    }
  });

  // === Individual Question Endpoints ===

  app.post('/api/questions', async (req: any, res: any) => {
    try {
      const parsed = questionSchema.parse(req.body);
      const created = await storage.createQuestion(parsed);
      res.status(201).json(created);
    } catch (err) {
      console.error("Error creating question:", err);
      res.status(400).json({ message: "Invalid question data", error: err });
    }
  });

  app.put('/api/questions/:id', async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id);
      const parsed = questionSchema.parse(req.body);
      const updated = await storage.updateQuestion(id, parsed);
      if (!updated) {
        return res.status(404).json({ message: "Question not found" });
      }
      res.json(updated);
    } catch (err) {
      console.error("Error updating question:", err);
      res.status(400).json({ message: "Invalid question data", error: err });
    }
  });

  app.delete('/api/questions/:id', async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteQuestion(id);
      if (!success) {
        return res.status(404).json({ message: "Question not found" });
      }
      res.status(204).send();
    } catch (err) {
      console.error("Error deleting question:", err);
      res.status(500).json({ message: "Failed to delete question", error: err });
    }
  });


  // === Sources Endpoints ===

  app.get('/api/sources', async (req: any, res: any) => {
    try {
      const sources = await storage.getSources();
      res.json(sources);
    } catch (err) {
      console.error("Error reading sources:", err);
      res.status(500).json({ message: "Failed to load sources" });
    }
  });

  app.get('/api/sources/active', async (req: any, res: any) => {
    try {
      const sources = await storage.getActiveSources();
      res.json(sources);
    } catch (err) {
      console.error("Error reading active sources:", err);
      res.status(500).json({ message: "Failed to load active sources" });
    }
  });

  app.get('/api/sources/active-ids', async (req: any, res: any) => {
    try {
      const sources = await storage.getActiveSources();
      res.json(sources.map(s => s.id));
    } catch (err) {
      console.error("Error reading active source IDs:", err);
      res.status(500).json({ message: "Failed to load active source IDs" });
    }
  });

  app.post('/api/sources', async (req: any, res: any) => {
    try {
      const parsed = sourceSchema.parse(req.body);
      const created = await storage.createSource(parsed);
      res.status(201).json(created);
    } catch (err) {
      console.error("Error creating source:", err);
      res.status(400).json({ message: "Invalid source data", error: err });
    }
  });

  app.put('/api/sources/:id', async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id);
      const parsed = sourceSchema.parse(req.body);
      const updated = await storage.updateSource(id, parsed);
      if (!updated) {
        return res.status(404).json({ message: "Source not found" });
      }
      res.json(updated);
    } catch (err) {
      console.error("Error updating source:", err);
      res.status(400).json({ message: "Invalid source data", error: err });
    }
  });

  app.patch('/api/sources/:id/active', async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id);
      const { isActive } = z.object({
        isActive: z.boolean()
      }).parse(req.body);

      const updated = await storage.toggleSourceActive(id, isActive);
      if (!updated) {
        return res.status(404).json({ message: "Source not found" });
      }
      res.json(updated);
    } catch (err) {
      console.error("Error toggling source active status:", err);
      res.status(400).json({ message: "Invalid request", error: err });
    }
  });

  app.delete('/api/sources/:id', async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteSource(id);
      if (!success) {
        return res.status(404).json({ message: "Source not found" });
      }
      res.status(204).send();
    } catch (err) {
      console.error("Error deleting source:", err);
      res.status(500).json({ message: "Failed to delete source", error: err });
    }
  });

  // === Access Code Endpoints (D/W/M/X) ===

  app.get('/api/access-code/today', async (_req: any, res: any) => {
    try {
      const todayDate = getTodaySAST();
      const code = generateDailyCode(todayDate);
      const timeLeft = getTimeUntilNextCode();
      res.json({ code, date: todayDate, expiresIn: timeLeft, type: 'daily' });
    } catch (err) {
      console.error("Error generating access code:", err);
      res.status(500).json({ message: "Failed to generate access code" });
    }
  });

  app.get('/api/access-code/lookup', async (req: any, res: any) => {
    try {
      const date = req.query.date as string;
      if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
        return res.status(400).json({ message: "Invalid date format. Use YYYY-MM-DD." });
      }
      const code = generateDailyCode(date);
      res.json({ code, date, type: 'daily' });
    } catch (err) {
      console.error("Error looking up access code:", err);
      res.status(500).json({ message: "Failed to look up access code" });
    }
  });

  // Unified login validation:
  // - Daily (D...): no mobile required. Accepts today's deterministic code
  //   OR an unexpired on-demand daily code from DB.
  // - Weekly/Monthly/Master (W/M/X...): requires 10-digit mobile linked at creation.
  app.post('/api/access-code/validate', async (req: any, res: any) => {
    try {
      const { code, mobileNumber } = z.object({
        code: z.string().min(1),
        mobileNumber: z.string().optional().nullable(),
      }).parse(req.body);

      const normalized = code.trim().toUpperCase();
      const type = getTypeFromCode(normalized);

      if (!type) {
        return res.json({ valid: false, message: "Unknown code type. Codes start with D, W, M or X." });
      }

      if (type === 'daily') {
        // 1) Deterministic daily code for today
        if (validateDailyCode(normalized)) {
          return res.json({ valid: true, type });
        }
        // 2) On-demand daily codes stored in DB
        const stored = await storage.getAccessCodeByCode(normalized);
        if (stored && stored.type === 'daily' && !stored.is_revoked) {
          if (stored.expires_at && new Date(stored.expires_at).getTime() < Date.now()) {
            return res.json({ valid: false, type, message: "Daily code expired." });
          }
          return res.json({ valid: true, type });
        }
        return res.json({ valid: false, type, message: "Invalid daily code." });
      }

      // W / M / X require linked mobile number
      const mobile = (mobileNumber || '').trim();
      if (!isValidMobile(mobile)) {
        return res.json({ valid: false, type, requiresMobile: true, message: "A 10-digit mobile number is required for this code." });
      }
      const stored = await storage.getAccessCodeByCode(normalized);
      if (!stored || stored.type !== type || stored.is_revoked) {
        return res.json({ valid: false, type, requiresMobile: true, message: "Invalid code." });
      }
      if ((stored.mobile_number || '').trim() !== mobile) {
        return res.json({ valid: false, type, requiresMobile: true, message: "Mobile number does not match this code." });
      }
      if (stored.expires_at && new Date(stored.expires_at).getTime() < Date.now()) {
        return res.json({ valid: false, type, requiresMobile: true, message: "Code expired." });
      }
      return res.json({ valid: true, type, requiresMobile: true });
    } catch (err) {
      console.error("Error validating access code:", err);
      res.status(500).json({ valid: false, message: "Failed to validate access code" });
    }
  });

  // --- On-demand code management (used by Session Access panel) ---

  app.get('/api/access-codes', async (_req: any, res: any) => {
    try {
      const codes = await storage.getAccessCodes();
      res.json(codes);
    } catch (err) {
      console.error("Error listing access codes:", err);
      res.status(500).json({ message: "Failed to list access codes" });
    }
  });

  app.post('/api/access-codes/generate', async (req: any, res: any) => {
    try {
      const { type, mobileNumber, hasAdminAccess } = z.object({
        type: z.enum(['daily', 'weekly', 'monthly', 'master']),
        mobileNumber: z.string().optional().nullable(),
        hasAdminAccess: z.boolean().optional().default(false),
      }).parse(req.body);

      const codeType = type as AccessCodeType;

      // Weekly/Monthly/Master MUST be linked to a 10-digit mobile
      if (requiresMobile(codeType)) {
        const mobile = (mobileNumber || '').trim();
        if (!MOBILE_NUMBER_REGEX.test(mobile)) {
          return res.status(400).json({ message: "A 10-digit mobile number is required for weekly, monthly and master codes." });
        }
      }

      // hasAdminAccess only applies to master keys
      const adminFlag = codeType === 'master' ? !!hasAdminAccess : false;

      // Generate a unique code (retry on collision)
      let code = '';
      for (let i = 0; i < 5; i++) {
        const candidate = generateOnDemandCode(codeType);
        const exists =
          codeType === 'daily' && validateDailyCode(candidate)
            ? true
            : !!(await storage.getAccessCodeByCode(candidate));
        if (!exists) {
          code = candidate;
          break;
        }
      }
      if (!code) {
        return res.status(500).json({ message: "Failed to generate a unique code, please try again." });
      }

      const created = await storage.createAccessCode({
        code,
        type: codeType,
        mobile_number: requiresMobile(codeType) ? (mobileNumber as string).trim() : null,
        has_admin_access: adminFlag,
        expires_at: getExpiryForType(codeType),
        is_revoked: false,
      });

      res.status(201).json(created);
    } catch (err) {
      console.error("Error generating access code:", err);
      res.status(400).json({ message: "Invalid generate payload", error: err });
    }
  });

  app.post('/api/access-codes/:id/revoke', async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (Number.isNaN(id)) return res.status(400).json({ message: "Invalid id" });
      const updated = await storage.revokeAccessCode(id);
      if (!updated) return res.status(404).json({ message: "Code not found" });
      res.json(updated);
    } catch (err) {
      console.error("Error revoking access code:", err);
      res.status(500).json({ message: "Failed to revoke access code" });
    }
  });

  app.delete('/api/access-codes/:id', async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (Number.isNaN(id)) return res.status(400).json({ message: "Invalid id" });
      const ok = await storage.deleteAccessCode(id);
      if (!ok) return res.status(404).json({ message: "Code not found" });
      res.status(204).send();
    } catch (err) {
      console.error("Error deleting access code:", err);
      res.status(500).json({ message: "Failed to delete access code" });
    }
  });

  // --- Admin console gate: only master keys flagged with admin access ---

  app.post('/api/access-codes/validate-admin', async (req: any, res: any) => {
    try {
      const { code, mobileNumber } = z.object({
        code: z.string().min(1),
        mobileNumber: z.string().min(1),
      }).parse(req.body);

      const normalized = code.trim().toUpperCase();
      const mobile = mobileNumber.trim();

      if (!normalized.startsWith('X')) {
        return res.json({ valid: false, message: "Admin access requires a master (X) key." });
      }
      if (!isValidMobile(mobile)) {
        return res.json({ valid: false, message: "A 10-digit mobile number is required." });
      }

      const stored = await storage.getAccessCodeByCode(normalized);
      if (!stored || stored.type !== 'master' || stored.is_revoked) {
        const mobileExists = stored && (stored.mobile_number || '').trim() === mobile;
        return res.json({
          valid: false,
          message: "Invalid master key.",
          // Hint for the "email admin" flow when mobile is right but key is wrong
          mobileMatch: !!mobileExists,
        });
      }
      if ((stored.mobile_number || '').trim() !== mobile) {
        return res.json({ valid: false, message: "Mobile number does not match this master key." });
      }
      if (!stored.has_admin_access) {
        return res.json({ valid: false, message: "This master key does not have admin access." });
      }
      return res.json({ valid: true, isAdmin: true });
    } catch (err) {
      console.error("Error validating admin access:", err);
      res.status(500).json({ valid: false, message: "Failed to validate admin access" });
    }
  });

  app.get('/api/admin/contact', async (_req: any, res: any) => {
    res.json({ email: getAdminEmail(), smtpConfigured: isSmtpConfigured() });
  });

  // User requests a new master key from the admin via backend email
  app.post('/api/admin/request-key', async (req: any, res: any) => {
    try {
      const { mobileNumber, message } = z.object({
        mobileNumber: z.string().regex(MOBILE_NUMBER_REGEX, "Mobile number must be 10 digits"),
        message: z.string().max(1000).optional().default(''),
      }).parse(req.body);

      const adminEmail = getAdminEmail();
      if (!adminEmail) {
        return res.status(500).json({ message: "ADMIN_EMAIL is not configured on the server." });
      }

      const subject = `Master key request — ${mobileNumber}`;
      const text = [
        `A user requested a new master key.`,
        ``,
        `Mobile: ${mobileNumber}`,
        `Time: ${new Date().toISOString()}`,
        message ? `` : ``,
        message ? `Message from user:` : ``,
        message ? message : ``,
      ].join('\n');

      await sendAdminEmail(subject, text);
      res.json({ sent: true, to: adminEmail });
    } catch (err: any) {
      console.error("Error sending admin request email:", err);
      const status = err?.message?.includes('SMTP') || err?.message?.includes('ADMIN_EMAIL') ? 500 : 400;
      res.status(status).json({ message: err?.message || "Failed to send request", error: err });
    }
  });


  // === Road Signs study module ===
  // NOTE: static sub-paths are registered BEFORE /:id so Express matches them first.

  app.get('/api/signs', async (req: any, res: any) => {
    try {
      const verified = req.query.verified;
      const signs = await storage.getSigns({
        heading: typeof req.query.heading === 'string' && req.query.heading ? req.query.heading : undefined,
        subheading: typeof req.query.subheading === 'string' && req.query.subheading ? req.query.subheading : undefined,
        search: typeof req.query.search === 'string' ? req.query.search : undefined,
        verified: verified === 'true' ? true : verified === 'false' ? false : undefined,
        missingImage: req.query.missingImage === 'true' ? true : undefined,
      });
      res.json(signs);
    } catch (err) {
      console.error("Error listing signs:", err);
      res.status(500).json({ message: "Failed to load signs" });
    }
  });

  // Bulk insert from Allsigns.json (raw format)
  app.post('/api/signs/import', async (req: any, res: any) => {
    try {
      const parsed = z.array(rawSignImportSchema).parse(req.body);
      const rows: InsertStudySign[] = parsed.map((r) => ({
        heading: r.Heading,
        subheading: r.Subheading,
        name: r.Name,
        codes: r.Codes,
        images: [],
        where_text: r.Where ?? null,
        purpose_text: r.Purpose ?? null,
        action_text: r.Action ?? null,
        is_verified_exam_question: false,
      }));
      const result = await storage.bulkInsertSigns(rows);
      res.status(201).json({ message: `Imported ${result.inserted} signs (${result.skipped} duplicates skipped).`, ...result });
    } catch (err) {
      console.error("Error importing signs:", err);
      res.status(400).json({ message: "Invalid signs import payload", error: err });
    }
  });

  // Batch image upload + auto-match by slugified code
  app.post('/api/signs/images/batch', async (req: any, res: any) => {
    try {
      const { files } = z.object({
        files: z.array(z.object({ filename: z.string(), dataUrl: z.string() })).min(1).max(50),
      }).parse(req.body);

      // Build slug -> { signId, code } lookup across every sign
      const signs = await storage.getSigns();
      const slugMap = new Map<string, { signId: number; code: string }>();
      for (const s of signs) {
        for (const code of s.codes || []) {
          const slug = slugifyCode(code);
          if (!slugMap.has(slug)) slugMap.set(slug, { signId: s.id, code });
        }
      }

      const matched: { filename: string; signId: number; code: string; image_url: string }[] = [];
      const staged: { filename: string; url: string }[] = [];
      for (const f of files) {
        const base = f.filename.replace(/\.[^.]+$/, '');
        const hit = slugMap.get(base) || slugMap.get(slugifyCode(base));
        if (hit) {
          try {
            const image_url = saveImageForCode(hit.code, f.filename, f.dataUrl);
            const sign = await storage.getSignById(hit.signId);
            if (sign) {
              const images = (sign.images || []).filter((i) => i.code !== hit.code);
              images.push({ code: hit.code, image_url });
              await storage.updateSign(hit.signId, { images });
            }
            matched.push({ filename: f.filename, signId: hit.signId, code: hit.code, image_url });
          } catch (e: any) {
            const s = stageImageUpload(f.filename, f.dataUrl);
            staged.push({ filename: s.filename, url: s.url });
          }
        } else {
          const s = stageImageUpload(f.filename, f.dataUrl);
          staged.push({ filename: s.filename, url: s.url });
        }
      }
      res.status(201).json({ matched, staged, unmatched: listStagedImages() });
    } catch (err) {
      console.error("Error batch-uploading sign images:", err);
      res.status(400).json({ message: "Invalid image batch payload", error: err });
    }
  });

  app.get('/api/signs/unmatched-images', async (_req: any, res: any) => {
    try {
      const signs = await storage.getSigns({ missingImage: true });
      const needsImage = signs.map((s) => ({
        signId: s.id,
        name: s.name,
        heading: s.heading,
        subheading: s.subheading,
        codes: (s.codes || []).filter((c) => !(s.images || []).some((i) => i.code === c)),
        images: s.images || [],
      }));
      res.json({ staged: listStagedImages(), needsImage });
    } catch (err) {
      console.error("Error listing unmatched images:", err);
      res.status(500).json({ message: "Failed to list unmatched images" });
    }
  });

  app.delete('/api/signs/unmatched-images/:filename', async (req: any, res: any) => {
    try {
      const ok = deleteStagedImage(req.params.filename);
      if (!ok) return res.status(404).json({ message: "Staged image not found" });
      res.status(204).send();
    } catch (err) {
      console.error("Error deleting staged image:", err);
      res.status(500).json({ message: "Failed to delete staged image" });
    }
  });

  app.get('/api/signs/:id', async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (Number.isNaN(id)) return res.status(400).json({ message: "Invalid id" });
      const sign = await storage.getSignById(id);
      if (!sign) return res.status(404).json({ message: "Sign not found" });
      res.json(sign);
    } catch (err) {
      console.error("Error reading sign:", err);
      res.status(500).json({ message: "Failed to load sign" });
    }
  });

  app.post('/api/signs', async (req: any, res: any) => {
    try {
      const parsed = studySignSchema.parse(req.body);
      const created = await storage.createSign(parsed);
      res.status(201).json(created);
    } catch (err) {
      console.error("Error creating sign:", err);
      res.status(400).json({ message: "Invalid sign data", error: err });
    }
  });

  app.patch('/api/signs/:id', async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (Number.isNaN(id)) return res.status(400).json({ message: "Invalid id" });
      const parsed = studySignSchema.partial().parse(req.body);
      const updated = await storage.updateSign(id, parsed);
      if (!updated) return res.status(404).json({ message: "Sign not found" });
      res.json(updated);
    } catch (err) {
      console.error("Error updating sign:", err);
      res.status(400).json({ message: "Invalid sign data", error: err });
    }
  });

  app.delete('/api/signs/:id', async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (Number.isNaN(id)) return res.status(400).json({ message: "Invalid id" });
      const ok = await storage.deleteSign(id);
      if (!ok) return res.status(404).json({ message: "Sign not found" });
      res.status(204).send();
    } catch (err) {
      console.error("Error deleting sign:", err);
      res.status(500).json({ message: "Failed to delete sign" });
    }
  });

  // Attach/replace an image for a specific code: fresh upload or staged file.
  // With addCodeAsNew, a code not yet on the record is appended first —
  // for staged images whose real code differs from the record's codes.
  app.post('/api/signs/:id/images', async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (Number.isNaN(id)) return res.status(400).json({ message: "Invalid id" });
      const { code, stagedFilename, filename, dataUrl, addCodeAsNew } = z.object({
        code: z.string().min(1),
        stagedFilename: z.string().optional(),
        filename: z.string().optional(),
        dataUrl: z.string().optional(),
        addCodeAsNew: z.boolean().optional().default(false),
      }).parse(req.body);

      const sign = await storage.getSignById(id);
      if (!sign) return res.status(404).json({ message: "Sign not found" });

      let finalCode = code.trim();
      if (!finalCode || finalCode.length > 40) {
        return res.status(400).json({ message: "Code must be 1–40 characters." });
      }
      let codes = sign.codes || [];
      if (!codes.includes(finalCode)) {
        if (!addCodeAsNew) {
          return res.status(400).json({ message: `Code "${finalCode}" does not belong to this sign. Pass addCodeAsNew to add it.` });
        }
        codes = [...codes, finalCode];
      }

      let image_url: string;
      if (stagedFilename) {
        image_url = attachStagedToCode(stagedFilename, finalCode);
      } else if (filename && dataUrl) {
        image_url = saveImageForCode(finalCode, filename, dataUrl);
      } else {
        return res.status(400).json({ message: "Provide stagedFilename or filename + dataUrl." });
      }

      const images = (sign.images || []).filter((i) => i.code !== finalCode);
      images.push({ code: finalCode, image_url });
      const updated = await storage.updateSign(id, { codes, images });
      res.status(201).json(updated);
    } catch (err: any) {
      console.error("Error attaching sign image:", err);
      res.status(400).json({ message: err?.message || "Failed to attach image" });
    }
  });

  // Remove a code from a sign record (image mapping dropped, file kept)
  app.delete('/api/signs/:id/codes/:code', async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (Number.isNaN(id)) return res.status(400).json({ message: "Invalid id" });
      const updated = await storage.removeSignCode(id, req.params.code);
      if (!updated) return res.status(404).json({ message: "Sign not found" });
      res.json(updated);
    } catch (err) {
      console.error("Error removing sign code:", err);
      res.status(500).json({ message: "Failed to remove code" });
    }
  });

  // Detach one image from a sign record (file kept on disk)
  app.delete('/api/signs/:id/images/:code', async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (Number.isNaN(id)) return res.status(400).json({ message: "Invalid id" });
      const updated = await storage.removeSignImage(id, req.params.code);
      if (!updated) return res.status(404).json({ message: "Sign not found" });
      res.json(updated);
    } catch (err) {
      console.error("Error removing sign image:", err);
      res.status(500).json({ message: "Failed to remove image" });
    }
  });

  app.get('/api/signs/:id/questions', async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (Number.isNaN(id)) return res.status(400).json({ message: "Invalid id" });
      res.json(await storage.getQuestionsForSign(id));
    } catch (err) {
      console.error("Error reading sign questions:", err);
      res.status(500).json({ message: "Failed to load linked questions" });
    }
  });

  app.post('/api/signs/:id/questions', async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (Number.isNaN(id)) return res.status(400).json({ message: "Invalid id" });
      const { question_id } = z.object({ question_id: z.number() }).parse(req.body);
      const link = await storage.linkSignQuestion(id, question_id);
      res.status(201).json(link);
    } catch (err: any) {
      console.error("Error linking sign question:", err);
      res.status(400).json({ message: err?.message || "Failed to link question" });
    }
  });

  app.delete('/api/signs/:id/questions/:questionId', async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id, 10);
      const questionId = parseInt(req.params.questionId, 10);
      if (Number.isNaN(id) || Number.isNaN(questionId)) return res.status(400).json({ message: "Invalid id" });
      const ok = await storage.unlinkSignQuestion(id, questionId);
      if (!ok) return res.status(404).json({ message: "Link not found" });
      res.status(204).send();
    } catch (err) {
      console.error("Error unlinking sign question:", err);
      res.status(500).json({ message: "Failed to unlink question" });
    }
  });

  // === Rules of the Road study module ===
  // Static sub-paths registered BEFORE /:id.

  app.get('/api/rules', async (req: any, res: any) => {
    try {
      const verified = req.query.verified;
      const codeParam = req.query.code;
      const code = typeof codeParam === 'string' && /^[123]$/.test(codeParam) ? parseInt(codeParam, 10) : undefined;
      const rules = await storage.getRules({
        code,
        heading: typeof req.query.heading === 'string' && req.query.heading ? req.query.heading : undefined,
        subheading: typeof req.query.subheading === 'string' && req.query.subheading ? req.query.subheading : undefined,
        search: typeof req.query.search === 'string' ? req.query.search : undefined,
        verified: verified === 'true' ? true : verified === 'false' ? false : undefined,
        missingQuestion: req.query.missingQuestion === 'true' ? true : undefined,
        unreviewed: req.query.unreviewed === 'true' ? true : undefined,
      });
      res.json(rules);
    } catch (err) {
      console.error("Error listing rules:", err);
      res.status(500).json({ message: "Failed to load rules" });
    }
  });

  // Bulk insert from rules-of-the-road-cards.json
  app.post('/api/rules/import', async (req: any, res: any) => {
    try {
      const parsed = z.array(rawRuleImportSchema).parse(req.body);
      const rows: InsertStudyRule[] = parsed.map((r) => ({
        section_ref: r.section_ref,
        heading: r.heading,
        subheading: r.subheading,
        title: r.title ?? null,
        body: r.body,
        applicable_codes: r.applicable_codes,
        is_verified_exam_question: false,
        is_reviewed: false,
      }));
      const result = await storage.bulkInsertRules(rows);
      res.status(201).json({ message: `Imported ${result.inserted} rules (${result.skipped} duplicates skipped).`, ...result });
    } catch (err) {
      console.error("Error importing rules:", err);
      res.status(400).json({ message: "Invalid rules import payload", error: err });
    }
  });

  app.get('/api/rules/:id', async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (Number.isNaN(id)) return res.status(400).json({ message: "Invalid id" });
      const rule = await storage.getRuleById(id);
      if (!rule) return res.status(404).json({ message: "Rule not found" });
      res.json(rule);
    } catch (err) {
      console.error("Error reading rule:", err);
      res.status(500).json({ message: "Failed to load rule" });
    }
  });

  app.post('/api/rules', async (req: any, res: any) => {
    try {
      const parsed = studyRuleSchema.parse(req.body);
      const created = await storage.createRule(parsed);
      res.status(201).json(created);
    } catch (err) {
      console.error("Error creating rule:", err);
      res.status(400).json({ message: "Invalid rule data", error: err });
    }
  });

  app.patch('/api/rules/:id', async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (Number.isNaN(id)) return res.status(400).json({ message: "Invalid id" });
      const parsed = studyRuleSchema.partial().parse(req.body);
      const updated = await storage.updateRule(id, parsed);
      if (!updated) return res.status(404).json({ message: "Rule not found" });
      res.json(updated);
    } catch (err) {
      console.error("Error updating rule:", err);
      res.status(400).json({ message: "Invalid rule data", error: err });
    }
  });

  app.delete('/api/rules/:id', async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (Number.isNaN(id)) return res.status(400).json({ message: "Invalid id" });
      const ok = await storage.deleteRule(id);
      if (!ok) return res.status(404).json({ message: "Rule not found" });
      res.status(204).send();
    } catch (err) {
      console.error("Error deleting rule:", err);
      res.status(500).json({ message: "Failed to delete rule" });
    }
  });

  app.get('/api/rules/:id/questions', async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (Number.isNaN(id)) return res.status(400).json({ message: "Invalid id" });
      res.json(await storage.getQuestionsForRule(id));
    } catch (err) {
      console.error("Error reading rule questions:", err);
      res.status(500).json({ message: "Failed to load linked questions" });
    }
  });

  app.post('/api/rules/:id/questions', async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (Number.isNaN(id)) return res.status(400).json({ message: "Invalid id" });
      const { question_id } = z.object({ question_id: z.number() }).parse(req.body);
      const link = await storage.linkRuleQuestion(id, question_id);
      res.status(201).json(link);
    } catch (err: any) {
      console.error("Error linking rule question:", err);
      res.status(400).json({ message: err?.message || "Failed to link question" });
    }
  });

  app.delete('/api/rules/:id/questions/:questionId', async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id, 10);
      const questionId = parseInt(req.params.questionId, 10);
      if (Number.isNaN(id) || Number.isNaN(questionId)) return res.status(400).json({ message: "Invalid id" });
      const ok = await storage.unlinkRuleQuestion(id, questionId);
      if (!ok) return res.status(404).json({ message: "Link not found" });
      res.status(204).send();
    } catch (err) {
      console.error("Error unlinking rule question:", err);
      res.status(500).json({ message: "Failed to unlink question" });
    }
  });


  return _httpServer;
}